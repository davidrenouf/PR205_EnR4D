#! /usr/bin/bash

java -jar SimulateMeteo.jar
sed 's:\\::g' ./mappings/stubFile.json
